# Use a trained DenseFuse Net to generate fused images

import tensorflow as tf
import numpy as np
from scipy.misc import imread, imsave
from datetime import datetime
from os import listdir, mkdir, sep
from os.path import join, exists, splitext
import time

WEIGHT_INIT_STDDEV = 0.05


def feature_extract(ir_path, vis_path, model_path, index, output_path = None, layer_index = 0):
	ir_img = imread(ir_path) / 255.0
	vis_img = imread(vis_path) / 255.0
	ir_dimension = list(ir_img.shape)
	vis_dimension = list(vis_img.shape)
	ir_dimension.insert(0, 1)
	ir_dimension.append(1)
	vis_dimension.insert(0, 1)
	vis_dimension.append(1)
	ir_img = ir_img.reshape(ir_dimension)
	vis_img = vis_img.reshape(vis_dimension)


	with tf.Graph().as_default(), tf.Session() as sess:
		SOURCE_VIS = tf.placeholder(tf.float32, shape = vis_dimension, name = 'SOURCE_VIS')
		SOURCE_IR = tf.placeholder(tf.float32, shape = ir_dimension, name = 'SOURCE_ir')
		# source_field = tf.placeholder(tf.float32, shape = source_shape, name = 'source_imgs')
		featuremap1 = EncoderA('Generator').encode(vis=SOURCE_VIS, ir=SOURCE_IR, layer_index = layer_index)
		featuremap2 = EncoderB('Generator').encode(vis=SOURCE_VIS, ir=SOURCE_IR, layer_index = layer_index)



		# restore the trained model and run the style transferring
		saver = tf.train.Saver()
		saver.restore(sess, model_path)
		output1 = sess.run(featuremap1, feed_dict = {SOURCE_VIS: vis_img, SOURCE_IR: ir_img})
		print('shape of output1:',output1.shape)
		for j in range(16):
			print('第%d层编码第%d通道'%((layer_index+1),j))
			imsave(output_path + 'feature_mapsA/' +str(index) + '_'+ str(layer_index+1) + '_' + str(j) + '.bmp',
				   output1[0, :, :, j])
		output2 = sess.run(featuremap2, feed_dict={SOURCE_VIS: vis_img, SOURCE_IR: ir_img})
		print('shape of output2:', output2.shape)
		for j in range(16):
			print('第%d层编码第%d通道' %((layer_index+1),j))
			imsave(output_path + 'feature_mapsB/' + str(index) + '_'+str(layer_index+1) + '_' + str(j) + '.bmp',
				   output2[0, :, :, j])



class EncoderA(object):
	def __init__(self, scope_name):
		self.scopeA = scope_name
		self.weight_varsA = []
		with tf.variable_scope(self.scopeA):
			with tf.variable_scope(self.scopeA):
				with tf.variable_scope('encoderA'):
					self.weight_varsA.append(self._create_variablesA(1, 16, 3, scope='Aconv1_1'))
					self.weight_varsA.append(self._create_variablesA(16, 16, 3, scope='Adense_block_conv1'))
					self.weight_varsA.append(self._create_variablesA(32, 16, 3, scope='Adense_block_conv2'))
					self.weight_varsA.append(self._create_variablesA(48, 16, 3, scope='Adense_block_conv3'))

	def encode(self, vis, ir,train=True, output_path=None, layer_index = None):
		dense_indices = [1, 2, 3, 4]
		image = tf.concat([vis, vis, ir], 3)
		out = image
		print('即将开始编码A,layer_index为%d'%layer_index)
		for i in range(layer_index+1):
			print('开始编码A')
			kernel, bias = self.weight_varsA[i]
			if i in dense_indices:
				out = conv2d(out, kernel, bias, dense = True, use_relu = True,
				             Scope = self.scopeA + '/encoderA/b' + str(i))
			else:
				out = conv2d(out, kernel, bias, dense = False, use_relu = True,
				             Scope = self.scopeA + '/encoderA/b' + str(i))
				#print('shape of out:',out[0].shape)
				print('shape of out:',out.shape)


			print('extract encodeA success')
			#print('A第%d层编码'%(i+1))
			if i == len(self.weight_varsA)-1:print('encodeA end')
		return out

	def _create_variablesA(self, input_filters, output_filters, kernel_size, scope):
		shape = [kernel_size, kernel_size, input_filters, output_filters]
		with tf.variable_scope(scope):
			kernel = tf.Variable(tf.truncated_normal(shape, stddev=WEIGHT_INIT_STDDEV),
								 name='kernelA')
			bias = tf.Variable(tf.zeros([output_filters]), name='biasA')
		return (kernel, bias)


class EncoderB(object):
	def __init__(self, scope_name):
		self.scopeB = scope_name
		self.weight_varsB = []
		with tf.variable_scope(self.scopeB):
			with tf.variable_scope(self.scopeB):
				with tf.variable_scope('encoderB'):
					self.weight_varsB.append(self._create_variablesB(1, 16, 3, scope='Bconv1_1'))
					self.weight_varsB.append(self._create_variablesB(16, 16, 3, scope='Bdense_block_conv1'))
					self.weight_varsB.append(self._create_variablesB(32, 16, 3, scope='Bdense_block_conv2'))
					self.weight_varsB.append(self._create_variablesB(48, 16, 3, scope='Bdense_block_conv3'))


	def encode(self,vis, ir, train=True, output_path=None, layer_index = 0):
		dense_indices = [1, 2, 3, 4]
		image = tf.concat([ir,ir,vis],3)
		out = image
		print('即将开始编码B,layer_index为%d'%layer_index)
		for i in range(layer_index+1):
			print('开始编码B')
			kernel, bias = self.weight_varsB[i]
			if i in dense_indices:
				out = conv2d(out, kernel, bias, dense = True, use_relu = True,
				             Scope = self.scopeB + '/encoderB/b' + str(i))
			else:
				out = conv2d(out, kernel, bias, dense = False, use_relu = True,
				             Scope = self.scopeB + '/encoderB/b' + str(i))

			print('extract encodeB success')
			#print('B第%d层编码'%(i+1))
			if i == len(self.weight_varsB)-1:print('encodeB end')
		return out

	def _create_variablesB(self, input_filters, output_filters, kernel_size, scope):
		shape = [kernel_size, kernel_size, input_filters, output_filters]
		with tf.variable_scope(scope):
			kernel = tf.Variable(tf.truncated_normal(shape, stddev=WEIGHT_INIT_STDDEV),
								 name='kernelB')
			bias = tf.Variable(tf.zeros([output_filters]), name='biasB')
		return (kernel, bias)


def info_measure(ir_path, vis_path, model_path, index, output_path = None, layer_index = 0):
	ir_img = imread(ir_path) / 255.0
	vis_img = imread(vis_path) / 255.0
	ir_dimension = list(ir_img.shape)
	vis_dimension = list(vis_img.shape)
	ir_dimension.insert(0, 1)
	ir_dimension.append(1)
	vis_dimension.insert(0, 1)
	vis_dimension.append(1)
	ir_img = ir_img.reshape(ir_dimension)
	vis_img = vis_img.reshape(vis_dimension)

	with tf.Graph().as_default(), tf.Session() as sess:
		SOURCE_VIS = tf.placeholder(tf.float32, shape = vis_dimension, name = 'SOURCE_VIS')
		SOURCE_IR = tf.placeholder(tf.float32, shape = ir_dimension, name = 'SOURCE_ir')
		# source_field = tf.placeholder(tf.float32, shape = source_shape, name = 'source_imgs')
		featuremap1 = EncoderA('Generator').encode(vis=SOURCE_VIS, ir=SOURCE_IR, layer_index = layer_index)
		featuremap2 = EncoderB('Generator').encode(vis=SOURCE_VIS, ir=SOURCE_IR, layer_index = layer_index)

		# restore the trained model and run the style transferring
		saver = tf.train.Saver()
		saver.restore(sess, model_path)
		output1 = sess.run(featuremap1, feed_dict = {SOURCE_VIS: vis_img, SOURCE_IR: ir_img})
		print('shape of output1:',output1.shape)
		for j in range(16):
			print('第%d层编码第%d通道'%((layer_index+1),j))
			imsave(output_path + 'feature_mapsA/' +str(index) + '_'+ str(layer_index+1) + '_' + str(j) + '.bmp',
				   output1[0, :, :, j])
		output2 = sess.run(featuremap2, feed_dict={SOURCE_VIS: vis_img, SOURCE_IR: ir_img})
		print('shape of output2:', output2.shape)
		for j in range(16):
			print('第%d层编码第%d通道' %((layer_index+1),j))
			imsave(output_path + 'feature_mapsB/' + str(index) + '_'+str(layer_index+1) + '_' + str(j) + '.bmp',
				   output2[0, :, :, j])



def conv2d(x, kernel, bias, dense = False, use_relu = True, Scope = None, BN = True):
	# padding image with reflection mode
	#print('  卷积前形状：',x.shape)
	x_padded = tf.pad(x, [[0, 0], [1, 1], [1, 1], [0, 0]], mode = 'REFLECT')
	# conv and add bias
	out = tf.nn.conv2d(x_padded, kernel, strides = [1, 1, 1, 1], padding = 'VALID')
	out = tf.nn.bias_add(out, bias)

	if BN:
		with tf.variable_scope(Scope):
			out = tf.layers.batch_normalization(out, training = True)
	if use_relu:
		out = tf.nn.relu(out)
	if dense:
		out = tf.concat([out, x], 3)
	#print('  卷积后的形状：', out.shape)
	#print('卷积结束')
	return out


def save_images(paths, datas, save_path, prefix = None, suffix = None):
	if isinstance(paths, str):
		paths = [paths]

	assert (len(paths) == len(datas))

	if not exists(save_path):
		mkdir(save_path)

	if prefix is None:
		prefix = ''
	if suffix is None:
		suffix = ''

	for i, path in enumerate(paths):
		data = datas[i]
		# print('data ==>>\n', data)
		if data.shape[2] == 1:
			data = data.reshape([data.shape[0], data.shape[1]])
		# print('data reshape==>>\n', data)

		name, ext = splitext(path)
		name = name.split(sep)[-1]

		path = join(save_path, prefix + suffix + ext)
		print('data path==>>', path)
		imsave(path, data)
