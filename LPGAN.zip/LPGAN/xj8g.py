from __future__ import print_function

import scipy.io as scio
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import time
from scipy.misc import imsave
import scipy.ndimage

from Generator import Generator
from Discriminator import Discriminator1, Discriminator2
#from LOSS import SSIM_LOSS, L1_LOSS, Fro_LOSS, _tf_fspecial_gauss
from generate import generate
from Generator import Decoder
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "8"
import glob
import math
from skimage.feature import local_binary_pattern




sess = tf.Session()

def L2_LOSS(batchimg):
	L1_norm = tf.reduce_sum(tf.abs(batchimg), axis=[1, 2])
	# tf.norm(batchimg, axis = [1, 2], ord = 1) / int(batchimg.shape[1])
	E = tf.reduce_mean(L1_norm)
	return E

def gradxy(img):
	kernelx = tf.constant([[0.0, 0.0, 0.0], [1.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernelx = tf.expand_dims(kernelx, axis=-1)
	kernelx = tf.expand_dims(kernelx, axis=-1)
	gx = tf.nn.conv2d(img, kernelx, strides=[1, 1, 1, 1], padding='SAME')
	kernely = tf.constant([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernely = tf.expand_dims(kernely, axis=-1)
	kernely = tf.expand_dims(kernely, axis=-1)
	gy = tf.nn.conv2d(img, kernely, strides=[1, 1, 1, 1], padding='SAME')
	#g = tf.reduce_sum(tf.sqrt(tf.square(gx, gy)), axis=[1, 2])

	return gx, gy

def direction(img):
	gx, gy = gradxy(img)
	angle = tf.atan2(gy, gx)
	zero = tf.zeros_like(angle)
	angle = tf.cond(tf.reduce_mean(angle-zero) < 0, lambda:angle + math.pi, lambda: angle + 0.0)
	return angle

def dirc(img):
	gx, gy = gradxy(img)
	angle = tf.atan2(gy, gx)
	#zero = tf.zeros_like(angle)
	#angle = tf.cond(tf.reduce_mean(angle - zero) < 0, lambda: angle + math.pi, lambda: angle + 0.0)
	#angle = math.atan2(gy,gx)
	out = angle.eval(session=sess)
	gy = gy.eval(session=sess)
	for i in range(out.shape[0]):
		for j in range(out.shape[1]):
			for r in range(out.shape[2]):
				if gy[i, j, r, 0] < 0:
					out[i, j, r, 0] += math.pi

	out = tf.convert_to_tensor(out)
	out = out/math.pi*180
	return out

def gradmod(img):
	gx, gy = gradxy(img)
	g = tf.sqrt(tf.square(gx)+tf.square(gy))
	#g = tf.squeeze(g, axis=-1)
	return g
#print(sess.run(tf.atan2(-1.0,0.0)+math.pi))

#img = tf.constant([[[[1.0],[2.0],[3.0]],[[2.0],[3.0],[4.0]],[[4.0],[5.0],[6.0]]],[[[5.0],[2.0],[3.0]],[[2.0],[3.0],[4.0]],[[4.0],[5.0],[6.0]]],[[[5.0],[2.0],[3.0]],[[2.0],[3.0],[4.0]],[[4.0],[5.0],[6.0]]]])
'''gx,gy = gradxy(img)
#out = img.eval(session=sess)
dirction = dirc(img)
#print(dirction)
#print(sess.run(dirction))
#print(sess.run(dirction.read_value()))
ones = tf.ones_like(img)
twos = ones*2'''

'''print(img[0,:,:,0].shape)
print(sess.run(img[0,:,:,0]))
print(img[0,:,:,0].eval(session=sess))
'''
eps = 1e-4

def info(img,alpha=1.0):
	kernel = tf.constant([[1/9, 1/9, 1/9], [1/9, 1/9, 1/9], [1/9, 1/9, 1/9]])
	kernel = tf.expand_dims(kernel, axis=-1)
	kernel = tf.expand_dims(kernel, axis=-1)

	gradient = tf.abs(gradmod(img))
	gradient = (gradient - tf.reduce_min(gradient)) / (tf.reduce_max(gradient) - tf.reduce_min(gradient))

	indensity = tf.nn.conv2d(img, kernel, strides = [1, 1, 1, 1], padding = 'SAME')
	#indensity = (indensity - tf.reduce_min(indensity)) / (tf.reduce_max(indensity) - tf.reduce_min(indensity))

	information = indensity + alpha * gradient
	information = (information-tf.reduce_min(information))/(tf.reduce_max(information)-tf.reduce_min(information)) + eps
	return information


import cv2



def uniform_pattern_LBP(img, radius=3, neighbors=8):
	h, w = img.shape
	dst = np.zeros((h - 2 * radius, w - 2 * radius), dtype=float)
	#LBP特征值对应图像灰度编码表，直接默认采样点为8位
	temp = 1
	table = np.zeros((256), dtype=float)
	for i in range(256):
		if getHopTimes(i) < 3:
			table[i] = temp
			temp += 1
	#是否进行UniformPattern编码的标志
	flag = False
	#计算LBP特征图
	for k in range(neighbors):
		if k == neighbors - 1:
			flag = True

		# 计算采样点对于中心点坐标的偏移量rx，ry
		rx = radius * np.cos(2.0 * np.pi * k / neighbors)
		ry = -(radius * np.sin(2.0 * np.pi * k / neighbors))
		# 为双线性插值做准备
        # 对采样点偏移量分别进行上下取整
		x1 = int(np.floor(rx))
		x2 = int(np.ceil(rx))
		y1 = int(np.floor(ry))
		y2 = int(np.ceil(ry))
		# 将坐标偏移量映射到0-1之间
		tx = rx - x1
		ty = ry - y1
		# 根据0-1之间的x，y的权重计算公式计算权重，权重与坐标具体位置无关，与坐标间的差值有关
		w1 = (1 - tx) * (1 - ty)
		w2 = tx * (1 - ty)
		w3 = (1 - tx) * ty
		w4 = tx * ty
		# 循环处理每个像素
		for i in range(radius, h - radius):
			for j in range(radius, w - radius):
				# 获得中心像素点的灰度值
				center = img[i, j]
				# 根据双线性插值公式计算第k个采样点的灰度值
				neighbor = img[i + y1, j + x1] * w1 + img[i + y2, j + x1] * w2 + img[i + y1, j + x2] * w3 + img[
					i + y2, j + x2] * w4
				# LBP特征图像的每个邻居的LBP值累加，累加通过与操作完成，对应的LBP值通过移位取得
				dst[i - radius, j - radius] |= (neighbor > center) << (np.uint8)(neighbors - k - 1)
				# 进行LBP特征的UniformPattern编码
				if flag:
					dst[i - radius, j - radius] = table[dst[i - radius, j - radius]]
	return dst


def getHopTimes(data):
	'''
	计算跳变次数
	'''
	count = 0
	binaryCode = "{0:0>8b}".format(data)

	for i in range(1, len(binaryCode)):
		if binaryCode[i] != binaryCode[(i - 1)]:
			count += 1
	return count



#print(sess.run(img[0,:,:,0]))
#print(img[0,:,:,0].shape)
'''im = tf.random_normal([256,256],mean=150,stddev=50)
out = im.eval(session=sess)
#print(sess.run(im))
uniformlbp = local_binary_pattern(out,8,2,method= 'nri_uniform')
#up = uniform_pattern_LBP(im,3,8)
print(uniformlbp)'''

#print(sess.run(up))

#print(sess.run(img*ones))
'''print('*************************')
print(img.shape)
print(sess.run(img))
#print(info(img).shape)
ir = tf.expand_dims(img[:,:,:,0], axis=-1)
#print(info(ir).shape)
#print(sess.run(info(ir)))
ir = ir * info(ir)
at = info(ir)
for i in range(1,img.shape[-1]):
	irr = tf.expand_dims(img[:,:,:,i], axis=-1)
	irr = irr * info(irr)
	at = tf.concat([at,info(irr)],axis=-1)
	ir = tf.concat([ir,irr],axis=-1)
#img = img * info(img)

print(at.shape)
print(sess.run(at))
print(ir.shape)
print(sess.run(ir))'''
def grad_direction(img):
	gx, gy = gradxy(img)
	angle = tf.atan2(gy, gx)
	cond = angle < 0
	pis = tf.ones_like(angle) * math.pi
	return angle,tf.where(cond,angle+pis,angle)

'''angle, angle_ = grad_direction(img)
print(sess.run(angle))
print(sess.run(angle_))'''


'''def L1_LOSS(batchimg):
	L1_norm = tf.reduce_sum(tf.abs(batchimg), axis = [1, 2])
	# tf.norm(batchimg, axis = [1, 2], ord = 1) / int(batchimg.shape[1])
	E = tf.reduce_mean(L1_norm)
	return E

print(sess.run(L1_LOSS(img)))'''



#print(out)
'''for i in range(out.shape[0]):
	for j in range(out.shape[1]):
		for r in range(out.shape[2]):
			if out[i,j,r,0]>0 :
				out[i,j,r,0] = 0'''
#print(out)
#out = tf.convert_to_tensor(out)
#print(out)
#print(sess.run(tf.shape(gx)))
#print(sess.run(tf.shape(gradmod(img))))
#print(sess.run(direction(img)))
#print(sess.run(dirc(img)))


'''l = [0.0]*9
l[0] = 1.0
l[4] = -1.0
array = np.array(l)
array = array.reshape(3,3,1,1)
ll = array.tolist()
print(ll)
kernel = tf.constant(ll)

#kernell = tf.constant([[0.0, 0.0, 0.0], [1.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
g = tf.nn.conv2d(img, kernel, strides=[1, 1, 1, 1], padding='SAME')
print(sess.run(g))'''

'''def LBP(img):
	zero = tf.zeros_like(img)
	img_LBP = tf.zeros_like(img)
	for i in range(9):
		l = [0.0] * 9
		l[4] = -1.0
		if i == 4:
			continue
		l[i] = 1.0
		array = np.array(l)
		array = array.reshape(3, 3, 1, 1)
		ll = array.tolist()
		#print(i)
		#print(ll)
		kernel = tf.constant(ll)
		out = tf.nn.conv2d(img, kernel, strides=[1, 1, 1, 1], padding='SAME')
		#print(sess.run(out))
		img_LBP = tf.cond(out-zero < 0, lambda:img_LBP + 1, lambda:img_LBP+0)

	return img_LBP

#print(sess.run(LBP(img)))
print(sess.run(img[0,0,0,0]))
img[0,0,0,0]=img[0,0,0,0]+1
print(sess.run(img[0,0,0,0]))
tf.sign()'''


def ori_lbp(img):
	kernel1 = tf.constant([[1.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel1 = tf.expand_dims(kernel1, axis=-1)
	kernel1 = tf.expand_dims(kernel1, axis=-1)
	kernel2 = tf.constant([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel2 = tf.expand_dims(kernel2, axis=-1)
	kernel2 = tf.expand_dims(kernel2, axis=-1)
	kernel3 = tf.constant([[0.0, 0.0, 1.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel3 = tf.expand_dims(kernel3, axis=-1)
	kernel3 = tf.expand_dims(kernel3, axis=-1)
	kernel4 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 1.0], [0.0, 0.0, 0.0]])
	kernel4 = tf.expand_dims(kernel4, axis=-1)
	kernel4 = tf.expand_dims(kernel4, axis=-1)
	kernel5 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 1.0]])
	kernel5 = tf.expand_dims(kernel5, axis=-1)
	kernel5 = tf.expand_dims(kernel5, axis=-1)
	kernel6 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 1.0, 0.0]])
	kernel6 = tf.expand_dims(kernel6, axis=-1)
	kernel6 = tf.expand_dims(kernel6, axis=-1)
	kernel7 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 0.0], [1.0, 0.0, 0.0]])
	kernel7 = tf.expand_dims(kernel7, axis=-1)
	kernel7 = tf.expand_dims(kernel7, axis=-1)
	kernel8 = tf.constant([[0.0, 0.0, 0.0], [1.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel8 = tf.expand_dims(kernel8, axis=-1)
	kernel8 = tf.expand_dims(kernel8, axis=-1)
	kernels = [kernel1,kernel2,kernel3,kernel4,kernel5,kernel6,kernel7,kernel8]
	out = tf.zeros_like(img)
	zeros = tf.zeros_like(img)
	ones = tf.ones_like(img)
	for i in range(8):
		out_filter = tf.nn.conv2d(img,kernels[i],strides=[1,1,1,1],padding='SAME',name='ori_lbp')
		cond = out_filter < 0
		out_filter = tf.where(cond, zeros, ones)
		out += out_filter * 2**(i)

	#out = tf.floor(tf.math.log(out) / tf.math.log(2.))
	#cond = out < 0
	#out = tf.where(cond, zeros, out)
	#L = [0.]*256
	L = []
	for i in range(256):
		num = tf.ones_like(out) * i
		#cond = out == i
		#l = tf.where(out == tf.constant([i]), tf.add(l, one), l)
		l = tf.equal(out,num)
		print('shape of l:',l.shape)
		#l = tf.where(l, tf.constant([1.]), tf.constant([0.]))
		l = tf.cast(l, tf.float32)
		print('shape of CAST l:', l.shape)
		l = tf.reduce_sum(l, axis=(1,2))
		L.append(l)

	distribution = L[0]
	for i in range(1, 256):
		distribution = tf.concat([distribution,L[i]], axis=1)

	#distribution = distribution / tf.tile(tf.reshape(tf.reduce_sum(distribution, axis=1), [3, 1]), [1,256])
	return out, distribution



def lbp(img, cell_size=21):
	#计算整图的LBP
	kernel1 = tf.constant([[1.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel1 = tf.expand_dims(kernel1, axis=-1)
	kernel1 = tf.expand_dims(kernel1, axis=-1)
	kernel2 = tf.constant([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel2 = tf.expand_dims(kernel2, axis=-1)
	kernel2 = tf.expand_dims(kernel2, axis=-1)
	kernel3 = tf.constant([[0.0, 0.0, 1.0], [0.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel3 = tf.expand_dims(kernel3, axis=-1)
	kernel3 = tf.expand_dims(kernel3, axis=-1)
	kernel4 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 1.0], [0.0, 0.0, 0.0]])
	kernel4 = tf.expand_dims(kernel4, axis=-1)
	kernel4 = tf.expand_dims(kernel4, axis=-1)
	kernel5 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 1.0]])
	kernel5 = tf.expand_dims(kernel5, axis=-1)
	kernel5 = tf.expand_dims(kernel5, axis=-1)
	kernel6 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 1.0, 0.0]])
	kernel6 = tf.expand_dims(kernel6, axis=-1)
	kernel6 = tf.expand_dims(kernel6, axis=-1)
	kernel7 = tf.constant([[0.0, 0.0, 0.0], [0.0, -1.0, 0.0], [1.0, 0.0, 0.0]])
	kernel7 = tf.expand_dims(kernel7, axis=-1)
	kernel7 = tf.expand_dims(kernel7, axis=-1)
	kernel8 = tf.constant([[0.0, 0.0, 0.0], [1.0, -1.0, 0.0], [0.0, 0.0, 0.0]])
	kernel8 = tf.expand_dims(kernel8, axis=-1)
	kernel8 = tf.expand_dims(kernel8, axis=-1)
	kernels = [kernel1, kernel2, kernel3, kernel4, kernel5, kernel6, kernel7, kernel8]
	out = tf.zeros_like(img)
	zeros = tf.zeros_like(img)
	ones = tf.ones_like(img)
	for i in range(8):
		out_filter = tf.nn.conv2d(img, kernels[i], strides=[1, 1, 1, 1], padding='SAME', name='ori_lbp')
		cond = out_filter < 0
		out_filter = tf.where(cond, zeros, ones)
		out += out_filter * 2 ** (i)

	#计算cell的数量和分布
	num_x = img.shape[1] // cell_size
	num_y = img.shape[2] // cell_size

	#计算各个cell的LBP分布
	L = []
	for j in range(num_y):
		for i in range(num_x):
			lbp_cell = out[:,i*cell_size:(i+1)*cell_size,j*cell_size:(j+1)*cell_size,:]
			for n in range(256):
				num = tf.ones_like(lbp_cell) * n
				# cond = out == i
				# l = tf.where(out == tf.constant([i]), tf.add(l, one), l)
				l = tf.equal(lbp_cell, num)
				#print('shape of l:', l.shape)
				# l = tf.where(l, tf.constant([1.]), tf.constant([0.]))
				l = tf.cast(l, tf.float32)
				print('shape of CAST l:', l.shape)
				l = tf.reduce_sum(l, axis=(1, 2))
				L.append(l)

	#拼接
	distribution = L[0]
	for i in range(1, len(L)):
		distribution = tf.concat([distribution, L[i]], axis=1)

	return distribution

def info2(img,alpha=1.0,beta=1.0):
	kernel = tf.constant([[1/9, 1/9, 1/9], [1/9, 1/9, 1/9], [1/9, 1/9, 1/9]])
	kernel = tf.expand_dims(kernel, axis=-1)
	kernel = tf.expand_dims(kernel, axis=-1)

	gradient = tf.abs(gradmod(img))
	#gradient = (gradient - tf.reduce_min(gradient)) / (tf.reduce_max(gradient) - tf.reduce_min(gradient))
	info_grad = tf.reduce_sum(gradient, axis=[1,2,3])/84/84/255   #0-255
	#info_grad = tf.squeeze(info_grad,axis=-1)

	en = cal_entropy(img)
	return info_grad, en

def cal_entropy(img):
	L = []
	#cond = tf.reduce_max(img) <= 1
	#if tf.where(cond,lambda: True, lambda: False):
	img = img * 255
	img = tf.cast(img, tf.int16)
	for i in range(256):
		map = tf.ones_like(img) * i
		l = tf.equal(img, map)
		l = tf.cast(l, tf.float32)
		l_sum = tf.reduce_sum(l, axis=[1, 2])
		L.append(l_sum)

	info = L[0]
	# info = tf.expand_dims(info,axis=-1)
	for i in range(1, len(L)):
		# L[i] = tf.expand_dims(L[i],axis=-1)
		info = tf.concat([info, L[i]], axis=1)

	info = info/84./84.
	cond = info <= 0
	info = tf.where(cond, tf.ones_like(info), info)
	info_log = -tf.math.log(info) / np.math.log(2)
	en = info * info_log
	en = tf.reduce_sum(en, axis=-1)

	#en = -info * tf.math.log(info)
	#en = tf.reduce_sum(en,axis=-1)
	#en = tf.reduce_mean(en, axis=0)
	return en

eg = tf.random_normal([32,84,84,1], mean=.5,stddev=0.5 )
#eg = tf.constant(np.random.randint(0,255,[3,84,84,1]))
'''_, contribution = ori_lbp(eg)
gradient = tf.abs(gradmod(eg))
info_grad = tf.reduce_sum(gradient,axis= [1,2,3])
sess.run(contribution)
print(contribution.shape)
sess.run(gradient)
print(gradient.shape)
sess.run(info_grad)
print(info_grad.shape)
print(sess.run(info_grad))'''
print('*********************************')
grad, en = info2(eg)
gradient = tf.abs(gradmod(eg))
#en = cal_entropy(eg)
#sess.run(grad,ind,infor)
sess.run(grad)
sess.run(en)
sess.run(gradient)
print(grad.shape)
print(en.shape)
print(gradient.shape)
print(tf.reduce_sum(tf.abs(gradient), axis = [1,2]).shape)
print(tf.reduce_mean(grad, axis=-1))
'''print(sess.run(grad))
print(sess.run(en))
print(sess.run(-tf.math.log(en)))
print(sess.run(-tf.math.log(en)*en))'''

'''a = tf.constant([0,0,3.,2.,0])
cond = (a<=0)
ones = tf.ones_like(a)
b = tf.math.log(tf.where(cond,ones,a))/np.math.log(2)
print(sess.run(a))
print(sess.run(b))'''

#print(grad.shape)
#print(infor.shape)
'''L=[]
for i in range(256):
	map = tf.ones_like(eg) * i
	l = tf.equal(eg, map)
	l = tf.cast(l, tf.float32)
	l_sum = tf.reduce_sum(l, axis=[1,2])
	L.append(l_sum)

info = L[0]
#info = tf.expand_dims(info,axis=-1)
for i in range(1,len(L)):
	#L[i] = tf.expand_dims(L[i],axis=-1)
	info = tf.concat([info,L[i]],axis=1)
sess.run(info)
print(info.shape)
#sess.run(l_sum)
#print(l_sum.shape)'''
'''for i in range(eg.shape[0]):
	img = eg[i]
	sess.run(img)
	print(img.shape)
	#print(sess.run(img.shape))
	print(sess.run(tf.reduce_max(img)))'''

#imgg = tf.constant([[[[10.0],[2.0],[-30.0]],[[2.0],[-3.0],[4.0]],[[-40.0],[-5.0],[-6.0]]],[[[-5.0],[-20.0],[3.0]],[[-2.0],[3.0],[4.0]],[[4.0],[5.0],[6.0]]],[[[5.0],[2.0],[30.0]],[[2.0],[3.0],[4.0]],[[4.0],[50.0],[6.0]]]])
'''out, dis= ori_lbp(imgg)
print(sess.run(out))
print('*********************************')

print(sess.run(dis))
print(dis.shape)'''
'''imggg = tf.constant([[2.,2.],[2.,2.]])
print(sess.run(tf.norm(imgg,axis=[1,2],ord='fro')))
print(sess.run(tf.norm(imgg,axis=[1,2],ord=2)))'''

'''a = tf.constant([True,False,False])
b = tf.cast(a,tf.float32)
print(sess.run(b))
print(b.shape)'''




